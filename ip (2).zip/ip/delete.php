<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "ip");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 

 
// Attempt insert query execution
$sql = "TRUNCATE userreg";
if(mysqli_query($link, $sql)){
    echo "Records deleted successfully.";
    include 'admin_panel.php';
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 



// Close connection
mysqli_close($link);
?>