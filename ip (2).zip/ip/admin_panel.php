<html>
<head>
<title>Admin Panel - Nosgene </title>
<link rel="stylesheet" type="text/css" href="style_admin.css">
</head>


<body>



<div id="header">
<center><img src="admin.png">
<h3> Welcome to Admin Panel | NOSGENE </h3></center>
</div>

<div id="sidemenu">
 <ul>
     <li><a href="delete.php" target="_blank" name='delete'> Delete All Records </a></li>
     <li><form action="delete_one.php">
             ID:<br>
            <input type="text" name="id_delete" placeholder="Delete By Id">
         <br><br>
            <input type="submit" value="Delete" name='delete_one'>
</form> </li>
    
    <li><a href="deeloper.php" target="_blank"> Devlopers Option </a></li>
	

 </ul>	
</div>

<div id="data">
<br><br>

<center><h1>Data available</h1></center>
<?php


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "ip");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

    include 'login2.php';
	
	//add error_reporting(0); to remove errors 
	
	
	$sql = "SELECT * FROM userreg ORDER BY userreg.id DESC";
	$result = mysqli_query($link, $sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
   echo "<h4>ID: </h4>" . $row["id"]. "<br>" . "  Name: " . $row["Name"].  " <br> " .  "Email: " . $row["Email_id"] .  "<br>" . "Phone Number: " . $row["Phnumber"]."<br> Number of People  :".$row["Number"]."<br> Message :".$row["message"]."<br>Date And Time:" .$row["date_time"]." <br><br><br>";
	 }
} else {
    echo "<h3><center>No user data found!<center></h3>";
}
?>
</div>

</body>
</html>