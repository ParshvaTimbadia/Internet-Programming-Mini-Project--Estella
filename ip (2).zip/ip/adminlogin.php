<?php 
 
$host="localhos:8082t";
$user="root";
$password="";
$db="ip";
 
mysql_connect($host,$user,$password);
mysql_select_db($db);
 
if(isset($_POST['adminid'])){
    
    $uname=$_POST['adminid'];
    $password=$_POST['adminpass'];
    
    $sql="select * from adminlogin where Admin_id='".$uname."'AND Admin_pass='".$password."' limit 1";
    
    $result=mysql_query($sql);
    $rowcount=mysql_num_rows($result)
    if($rowcount==1){
        echo " You Have Successfully Logged in";
        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}
?>