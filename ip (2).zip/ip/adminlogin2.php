<?php

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

$link = mysqli_connect("localhost", "root", "", "ip");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$uname=mysqli_real_escape_string($link, $_REQUEST['adminid']);
$upass = mysqli_real_escape_string($link, $_REQUEST['adminpass']);

$sql_login="select * from adminlogin where Admin_id='$uname' AND Admin_password='$upass'";
    
    $result=mysqli_query($link,$sql_login);
    $rowcount=mysqli_num_rows($result);
    if($rowcount==1)
    {
        echo " You Have Successfully Logged in";
        header('Location: admin_panel.php');
        exit();
    }
    else
    {
        echo " You Have Entered Incorrect Password";
        exit();
    }



?>